package testcase;

import huawei.Demo;


import junit.framework.TestCase;

public class DemoTest extends TestCase {

	public void testCase01()
	{
		assertEquals(1, Demo.isSlurpy("AHDFG"));
		assertEquals(1, Demo.isSlurpy("AHEFG"));
		assertEquals(1, Demo.isSlurpy("AHDFFEFFG"));
		assertEquals(1, Demo.isSlurpy("AHEFFDFFFG"));
		assertEquals(1, Demo.isSlurpy("ABAHDFG"));
		assertEquals(1, Demo.isSlurpy("ABABAHEFFFG"));
		assertEquals(1, Demo.isSlurpy("ABABADFGCDFG"));
		assertEquals(1, Demo.isSlurpy("ADFGCDFG"));
		assertEquals(1, Demo.isSlurpy("AEFFGCDFFFG"));
		assertEquals(0, Demo.isSlurpy("ABABABDFG"));
		assertEquals(0, Demo.isSlurpy("ABABADFAFFG"));
		assertEquals(0, Demo.isSlurpy("ADFGC"));
	}

}
