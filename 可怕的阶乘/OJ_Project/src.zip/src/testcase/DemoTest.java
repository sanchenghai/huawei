package testcase;

import huawei.Demo;
import junit.framework.TestCase;

public class DemoTest extends TestCase {

  
	public void testCase01() 
	{
	    assertEquals(Demo.calcNN(13), "6227020800"); 	
	}	
}
