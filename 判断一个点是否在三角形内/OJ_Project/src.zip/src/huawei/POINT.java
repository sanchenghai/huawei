package huawei;

public class POINT {
	int x;
	int y;
	public POINT(int x,int y)
	{
		this.x=x;
		this.y=y;
	}
}
