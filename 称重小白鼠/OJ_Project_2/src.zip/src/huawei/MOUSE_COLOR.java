package huawei;

public enum MOUSE_COLOR {
	CL_RED,
	CL_BLUE,
	CL_BLACK,
	CL_WHITE,
	CL_YELLOW,
	CL_PINK,
	CL_GRAY
}
